﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour {

    public int rows = 10;
    public int cols = 25;
    public float gridSize = 2.08f;

    public Color gridColor;

    private void OnDrawGizmos()
    {
        Gizmos.color = gridColor;

        for(int x = 0; x <= cols; x++)
        {
            Gizmos.DrawLine(
                new Vector3(x * gridSize, 0, transform.position.z),
                new Vector3(x * gridSize, rows * gridSize, transform.position.z));
        }

        for (int y = 0; y <= rows; y++)
        {
            Gizmos.DrawLine(
                new Vector3(0, y * gridSize, transform.position.z),
                new Vector3(cols * gridSize, y * gridSize, transform.position.z));
        }

        SpriteRenderer[] sprites = GameObject.FindObjectsOfType<SpriteRenderer>();

        //print("Number of sprites found: " + sprites.Length);

        for (int i = 0; i < sprites.Length; i++)
        {
            //1. Find the center of the sprite
            SpriteRenderer currentSpriteRenderer = sprites[i];
            Sprite currentSprite = currentSpriteRenderer.sprite;

            //2. Center of sprite is wherever the SpriteRender's Transform is,
            // plus the sprite's bounds.center
            Vector3 spriteCenterWorld = currentSpriteRenderer.transform.position + currentSprite.bounds.center;

            //3. Convert to grid coordinates
            Vector3 spriteCenterGrid = new Vector3(
                Mathf.FloorToInt(spriteCenterWorld.x / gridSize),
                Mathf.FloorToInt(spriteCenterWorld.y / gridSize),
                currentSpriteRenderer.transform.position.z
                );

            //4. Convert back to world coordinates by scaling
            // grid coordinates by gridSize
            currentSpriteRenderer.transform.position = spriteCenterGrid * gridSize;

            //Gizmos.color = Color.red;
            //Gizmos.DrawSphere(currentSpriteRenderer.transform.position + currentSprite.bounds.center, 0.2f);
        }

    }
}
