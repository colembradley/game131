﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class simpleGizmos : MonoBehaviour {

    public Color gizmoSelectedColor;

    public Color gizmoColor;
    public Color gizmoWireColor;

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnDrawGizmos()
    {
        Gizmos.color = gizmoColor;
        Gizmos.DrawCube(transform.position, Vector3.one);

        Gizmos.color = gizmoWireColor;
        Gizmos.DrawWireCube(transform.position, Vector3.one);


    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = gizmoSelectedColor;
        Gizmos.DrawSphere(transform.position, 1);

        Gizmos.color = gizmoWireColor;
        Gizmos.DrawWireSphere(transform.position, 1);

        Gizmos.DrawLine(transform.position, transform.position *2);


    }
}
