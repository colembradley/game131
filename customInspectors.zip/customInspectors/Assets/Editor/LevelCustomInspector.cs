﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(Level))]
public class LevelCustomInspector : Editor {

    private Level _myTarget;

    private int newRows;
    private int newCols;

    private void OnEnable()
    {
        _myTarget = (Level)target;
    }

    public override void OnInspectorGUI()
    {
        _myTarget.rows = EditorGUILayout.IntField("Rows", _myTarget.rows);
        _myTarget.cols = EditorGUILayout.IntField("Columns", _myTarget.cols);

        newRows = EditorGUILayout.IntField("New Rows", newRows);
        newCols = EditorGUILayout.IntField("New Columns", newCols);

        bool currentGUIEnabledValue = GUI.enabled;

        if ((_myTarget.rows == newRows) && (_myTarget.cols == newCols))
        {
            GUI.enabled = false;
        }
        else
        {
            GUI.enabled = true;
        }

        bool resizeLevel = GUILayout.Button("Resize Level");
        if (resizeLevel)
        {
            _myTarget.rows = newRows;
            _myTarget.cols = newCols;
        }

        bool reset = GUILayout.Button("Reset");
        if (reset)
        {
            newRows = _myTarget.rows;
            newCols = _myTarget.cols;
        }

        GUI.enabled = currentGUIEnabledValue;

    }
}
