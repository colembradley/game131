﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Level : MonoBehaviour {

    public int rows = 10;
    public int cols = 20;

    public float totalTime = 60f;
    public float gravity = -30f;

    public AudioClip bgm;
    public Sprite background;

    void Start () {
		
	}
	
	void Update () {
		
	}
}
